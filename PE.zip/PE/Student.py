import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
import numpy as np
import csv


def add_record(hours, score):
    with open('Data.csv', 'a', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([hours, score])
    print("Record added!")


def load_data():
    try:
        return pd.read_csv('Data.csv', names=['Hours', 'Score'])
    except FileNotFoundError:
        open('Data.csv', 'w').close()
        return pd.DataFrame(columns=['Hours', 'Score'])

def feedback(hours, score):
    if hours < 2 and score <40:
        print("Study more!")
    elif hours > 8 and score < 80:
        print("Need to concentrate on study")
    elif score > 80:
        print(" Excellent work!")
    elif score > 50 and score < 70 and hours < 3:
        print("study more for getting next level")
    else:
        print(" Keep improving!")


def show_plot(data):
    plt.bar(data['Hours'], data['Score'],color='green')
    plt.title("Study Progress")
    plt.xlabel("Study Hours")
    plt.ylabel("Test Score (%)")
    plt.xlim(1, 24)
    plt.show()


def predict_score(data, next_hours):
    X = np.array(data['Hours']).reshape(-1, 1)
    y = np.array(data['Score'])
    model = LinearRegression()
    model.fit(X, y)
    pred = model.predict([[next_hours]])[0]
    print(f"Predicted score for {next_hours} hrs: {pred:.2f}%")


data = load_data()

while True:
    print("\n1.Add  2.Show Plot  3.Predict  4.Exit")
    c = input("Enter choice: ")

    if c == '1':
        h = float(input("Study hours: "))
        s = float(input("Test score: "))
        add_record(h, s)
        feedback(h, s)
    elif c == '2':
        data = load_data()
        if not data.empty:
            show_plot(data)
        else:
            print("No data yet!")
    elif c == '3':
        data = load_data()
        if not data.empty:
            nh = float(input("Enter next study hours: "))
            predict_score(data, nh)
        else:
            print("Add some data first!")
    elif c == '4':
        print("Bye! Keep studying smart ")
        break
    else:
        print("Invalid choice.")
